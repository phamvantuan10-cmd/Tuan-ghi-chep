# Bảng tính giọng nói (VoiceSheet)

Ứng dụng Android (Kotlin) nghe giọng nói, chuyển thành văn bản và ghi vào bảng tính giống Excel.

## Tính năng
- Nghe liên tục bằng giọng nói (Tiếng Việt / English), mỗi câu tự điền vào ô rồi sang ô kế tiếp
- Tự điền ngày giờ vào cột A (bật/tắt được)
- Lệnh thoại: "xuống dòng", "ô tiếp theo", "ô trước", "xóa ô" (English: new line, next cell, back, clear cell)
- Đổi tên cột, hàng Σ tự cộng tổng các số trong cột
- Lưu dữ liệu trên máy, chia sẻ/sao chép sang Excel hoặc Google Sheets, lưu file CSV

## Lấy file APK từ GitHub (không cần Android Studio)
1. Vào tab **Actions** của repo, chọn lần chạy **Build APK** mới nhất (hoặc bấm **Run workflow**).
2. Tải mục **VoiceSheet-debug-apk** ở cuối trang, giải nén ra `app-debug.apk`.
3. Chép sang điện thoại và cài đặt (cho phép cài từ nguồn không rõ nếu được hỏi).

## Build bằng Android Studio
Mở thư mục dự án, chờ Gradle đồng bộ, rồi bấm Run trên điện thoại đã bật Gỡ lỗi USB.

## Yêu cầu
Android 8.0 trở lên, có ứng dụng Google và Internet để nhận dạng giọng nói, cấp quyền micro lần đầu.
