package com.example.voicesheet

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val COLS = 5
    private val prefs by lazy { getSharedPreferences("vs", MODE_PRIVATE) }
    private var heads = mutableListOf("Thời gian", "Nội dung", "Ghi chú", "D", "E")
    private val data = mutableListOf<MutableList<String>>()
    private var cells = mutableListOf<List<EditText>>()
    private var sums = listOf<TextView>()
    private lateinit var table: TableLayout
    private lateinit var live: TextView
    private lateinit var mic: Button
    private lateinit var stampCb: CheckBox
    private lateinit var rightCb: CheckBox
    private lateinit var rIntent: Intent
    private var r = 0
    private var c = 1
    private var lang = "vi-VN"
    private var listening = false
    private var rec: SpeechRecognizer? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) begin() else toast("Cần cấp quyền micro để nghe.")
    }
    private val saveCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri?.let {
            contentResolver.openOutputStream(it)?.use { o ->
                o.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())); o.write(csv().toByteArray())
            }
            toast("Đã lưu file CSV")
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        load()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); fitsSystemWindows = true }
        mic = btn("🎤 Bắt đầu nghe") { if (listening) stop() else begin() }
        val langBtn = btn("Tiếng Việt") {
            lang = if (lang == "vi-VN") "en-US" else "vi-VN"
            (it as Button).text = if (lang == "vi-VN") "Tiếng Việt" else "English"
            if (listening) { stop(); begin() }
        }
        stampCb = CheckBox(this).apply {
            text = "Tự điền ngày giờ (cột A)"; isChecked = prefs.getBoolean("ts", true)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("ts", v).apply(); if (v && c == 0) c = 1 }
        }
        rightCb = CheckBox(this).apply { text = "Sang phải sau mỗi câu (mặc định: xuống dòng)" }
        val row1 = LinearLayout(this); row1.addW(mic); row1.addW(langBtn)
        val row2 = LinearLayout(this)
        row2.addW(btn("Chia sẻ") { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, tsv()) }, "Sao chép / chia sẻ")) })
        row2.addW(btn("Lưu CSV") { saveCsv.launch("ghi-chep.csv") })
        row2.addW(btn("+ Dòng") { data.add(MutableList(COLS) { "" }); buildTable() })
        row2.addW(btn("Xóa") {
            AlertDialog.Builder(this).setMessage("Xóa toàn bộ dữ liệu?").setNegativeButton("Hủy", null)
                .setPositiveButton("Xóa") { _, _ -> data.clear(); load(); data.clear(); repeat(25) { data.add(MutableList(COLS) { "" }) }; r = 0; c = 1; buildTable(); save() }.show()
        })
        live = TextView(this).apply { text = "Văn bản đang nghe sẽ hiện ở đây…"; setPadding(dp(4), dp(8), dp(4), dp(8)) }
        table = TableLayout(this)
        val vs = ScrollView(this); val hs = HorizontalScrollView(this)
        hs.addView(table); vs.addView(hs)
        listOf(row1, row2, stampCb, rightCb, live).forEach { root.addView(it) }
        root.addView(vs, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        buildTable(); setContentView(root)
    }

    private fun buildTable() {
        table.removeAllViews()
        val hr = TableRow(this); hr.addView(label("#"))
        for (i in 0 until COLS) hr.addView(EditText(this).apply {
            setText(heads[i]); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER; minWidth = dp(130)
            setBackgroundColor(0xFFEEF1F4.toInt()); setTextColor(Color.BLACK)
            addTextChangedListener(watch { heads[i] = it; save() })
        })
        table.addView(hr)
        cells = mutableListOf()
        data.forEachIndexed { ri, rowData ->
            val tr = TableRow(this); tr.addView(label("${ri + 1}"))
            val list = rowData.indices.map { ci ->
                EditText(this).apply {
                    setText(rowData[ci]); minWidth = dp(130); textSize = 14f
                    setOnFocusChangeListener { v, f -> if (f) { r = ri; c = ci; v.setBackgroundColor(0x3300A050) } else v.setBackgroundColor(Color.TRANSPARENT) }
                    addTextChangedListener(watch { data[ri][ci] = it; save(); updSums() })
                }
            }
            list.forEach { tr.addView(it) }; cells.add(list); table.addView(tr)
        }
        val sr = TableRow(this); sr.addView(label("Σ"))
        sums = (0 until COLS).map { label("–").also { t -> sr.addView(t) } }
        table.addView(sr); updSums()
    }

    private fun put(raw: String) {
        val text = raw.trim(); if (text.isEmpty()) return
        val k = text.lowercase().replace(Regex("[.,!?]"), "").trim()
        val cmd = mapOf("xuống dòng" to "nl", "dòng mới" to "nl", "ô tiếp theo" to "nx", "sang phải" to "nx", "ô trước" to "pv",
            "quay lại" to "pv", "xóa ô" to "cl", "new line" to "nl", "next cell" to "nx", "back" to "pv", "clear cell" to "cl")[k]
        val stamp = stampCb.isChecked
        if (cmd != null) {
            when (cmd) {
                "nl" -> go(r + 1, if (stamp) 1 else 0)
                "nx" -> go(r, c + 1)
                "pv" -> go(r, c - 1)
                else -> cells[r][c].setText("")
            }
            return
        }
        val row = r; val col = if (stamp && c == 0) 1 else c
        cells[row][col].setText(text)
        if (stamp && data[row][0].isEmpty()) cells[row][0].setText(SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date()))
        if (rightCb.isChecked) go(row, col + 1) else go(row + 1, col)
    }

    private fun go(r0: Int, c0: Int) {
        var nr = r0; var nc = c0
        if (nc >= COLS) { nc = if (stampCb.isChecked) 1 else 0; nr++ }
        if (nc < 0) { nc = COLS - 1; nr-- }
        if (nr < 0) nr = 0
        if (nr >= data.size) { while (nr >= data.size) data.add(MutableList(COLS) { "" }); buildTable() }
        r = nr; c = nc; cells[r][c].requestFocus()
    }

    private val listener = object : RecognitionListener {
        override fun onResults(b: Bundle?) {
            b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { put(it); live.text = "✔ $it" }
            again(0)
        }
        override fun onPartialResults(b: Bundle?) {
            b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { live.text = it }
        }
        override fun onError(e: Int) {
            if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stop(); toast("Chưa có quyền micro"); return }
            again(400)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun again(delay: Long) = live.postDelayed({ if (listening) { rec?.cancel(); rec?.startListening(rIntent) } }, delay)

    private fun begin() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Máy chưa có dịch vụ nhận dạng giọng nói (cần ứng dụng Google)."); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { permLauncher.launch(Manifest.permission.RECORD_AUDIO); return }
        rIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        rec = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener); it.startListening(rIntent) }
        listening = true; mic.text = "⏹ Dừng nghe"
    }

    private fun stop() { listening = false; rec?.destroy(); rec = null; mic.text = "🎤 Bắt đầu nghe" }
    override fun onDestroy() { stop(); super.onDestroy() }

    private fun num(v: String): Double? {
        var s = v.trim().replace(" ", "")
        s = if (Regex("^-?\\d{1,3}(\\.\\d{3})+(,\\d+)?$").matches(s)) s.replace(".", "").replace(",", ".")
        else if (Regex("^-?\\d+([.,]\\d+)?$").matches(s)) s.replace(",", ".") else return null
        return s.toDoubleOrNull()
    }
    private fun updSums() {
        if (sums.size != COLS) return
        val nf = NumberFormat.getInstance(Locale("vi", "VN")).apply { maximumFractionDigits = 2 }
        for (i in 0 until COLS) { var t = 0.0; var n = 0; data.forEach { x -> num(x[i])?.let { t += it; n++ } }; sums[i].text = if (n > 0) nf.format(t) else "–" }
    }

    private fun load() {
        try {
            prefs.getString("data", null)?.let { s -> val a = JSONArray(s); for (i in 0 until a.length()) { val ra = a.getJSONArray(i); data.add(MutableList(COLS) { ra.optString(it, "") }) } }
            prefs.getString("heads", null)?.let { val a = JSONArray(it); if (a.length() == COLS) heads = MutableList(COLS) { i -> a.getString(i) } }
        } catch (e: Exception) {}
        while (data.size < 25) data.add(MutableList(COLS) { "" })
    }
    private fun save() { prefs.edit().putString("data", JSONArray(data.map { JSONArray(it) }).toString()).putString("heads", JSONArray(heads).toString()).apply() }

    private fun rows() = data.filter { x -> x.any { it.isNotEmpty() } }
    private fun tsv() = (listOf(heads.joinToString("\t")) + rows().map { it.joinToString("\t") }).joinToString("\n")
    private fun csv(): String {
        val q = { s: String -> "\"" + s.replace("\"", "\"\"") + "\"" }
        return (listOf<List<String>>(heads) + rows()).joinToString("\r\n") { x -> x.joinToString(",") { q(it) } }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun label(t: String) = TextView(this).apply { text = t; setPadding(dp(8), dp(10), dp(8), dp(10)); setTypeface(null, Typeface.BOLD) }
    private fun btn(t: String, f: (View) -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener(f) }
    private fun LinearLayout.addW(v: View) = addView(v, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
    private fun watch(f: (String) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(a: CharSequence?, b: Int, c2: Int, d: Int) {}
        override fun onTextChanged(a: CharSequence?, b: Int, c2: Int, d: Int) {}
        override fun afterTextChanged(e: Editable?) { f(e?.toString() ?: "") }
    }
}
